var canvasContext = new Canvas('#canvas-panel');

canvasContext.DrawPointOnClick();